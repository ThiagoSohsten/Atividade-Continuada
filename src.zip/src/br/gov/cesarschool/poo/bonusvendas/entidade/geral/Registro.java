package br.gov.cesarschool.poo.bonusvendas.entidade.geral;

import java.io.Serializable;

public abstract class Registro implements Serializable{

	
	public abstract String getIdUnico();
	
	private static final long serialVersionUID = 1L;

}
