package br.gov.cesarschool.poo.bonusvendas.util;

public interface Comparador {
	
	int comparar(Object o1, Object o2);
}
